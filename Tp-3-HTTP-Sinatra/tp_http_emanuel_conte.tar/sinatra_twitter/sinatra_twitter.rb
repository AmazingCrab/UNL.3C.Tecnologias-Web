# coding: utf-8
# Mi super app de twitter
require 'sinatra'

# Página de inicio
get '/' do
  erb :index
end

get '/mostrar-tweet' do
  erb :tweet
end

post '/mostrar-tweet' do
  erb :tweet
end
